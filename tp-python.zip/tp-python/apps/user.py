from flask import Blueprint, jsonify, request
from helpers.user_helper import user_helper
from models import User
from models import Token
from playhouse.shortcuts import model_to_dict, dict_to_model
import hashlib
from token import create_token


app_user = Blueprint('app_user', __name__)

#Creation d'un article
@app_user.route('/user', methods=['POST'])
def create_user():
    params = request.get_json()
    email= params.get('email')
    try:
        test = User.get(User.email == email)
        return "Impossible, email utilise"

    except User.DoesNotExist:
        md5 = hashlib.md5()
        password = params.get('password')
        md5.update(password)
        user = User.create(email=email, password=md5.hexdigest())
        user.save()
        data = model_to_dict(user)
        return jsonify({'data': data }), 201


@app_user.route('/user/<id>', methods=['GET'])
def get_user(id):
    try:
        user= User.get(User.id == id)
        data = model_to_dict(user)
        return jsonify({'data': data }), 201
    except Exception as e:
        return jsonify({'error': e.message}), 404


@app_user.route('/user/<id>', methods=['PUT'])
def update_user(id):
   try:
       user = User.get(User.id == id)
       params = request.get_json()
       if params.get('email', None) is not None:
           user.email = params.get('email')
       if params.get('password', None) is not None:
           user.description = params.get('password')
       user.save()
       data = model_to_dict(user)
       return jsonify({'user': data}), 201
   except Exception as identifier:
       return jsonify({'error': 'Not found {message}'.format(message=identifier.message)}), 404

@app_user.route('/user/<id>', methods=['DELETE'])
def delete_user(id):
    try:
        user = User.get(User.id == id)
        token = Token.get(Token.user_id == id)
        user.delete_instance()
        token.delete_instance()
        return jsonify({'delete': 'ok'})
    except Exception as identifier:
        return jsonify({'error': 'Not found'})

@app_user.route('/user/', methods=['GET'])
def get_all_user():


        return jsonify({'users': list(User.select().dicts()) }), 201

@app_user.route('/auth/', methods=['POST'])
def auth_user():
        params = request.get_json()
        email= params.get('email')
        md5 = hashlib.md5()
        password = params.get('password')
        md5.update(password)
        try:
            user_found = User.get(User.email == email)
            if user_found.password == str(md5.hexdigest()) :
                try:
                    token_existing = Token.get(Token.user_id == user_found.id)
                    return jsonify({'User deja identifie sous le token': token_existing.ticket})
                except Exception as identifier :
                    token = create_token(user_found.id)
                    return jsonify({'User identifie sous le token': token})
            else :
                return "mauvais mot de passe"

        except Exception as identifier:
            return jsonify({'error': 'User Not found'})
