from flask import Blueprint, jsonify, request
from helpers.transaction_helper import transaction_helper
from models import User
from models import Token
from models import Transaction
from playhouse.shortcuts import model_to_dict, dict_to_model
import hashlib
from token import create_token
from token import check_token
import time
from datetime import datetime, timedelta



app_transaction = Blueprint('app_transaction', __name__)


#Creation d'une transaction

@app_transaction.route('/transaction', methods=['POST'])
def create_transaction():
    params = request.get_json()
    email= params.get('email')
    token = params.get('token')
    amount = params.get('amount')
    label = params.get('label')


    if check_token(email, token) is True:
        user_id= User.get(User.email == email).id
        transaction = Transaction.create(user_id= user_id,date = datetime.now(), amount= amount, label= label)
        transaction.save()
        data = model_to_dict(transaction)
        return jsonify({'data': data }), 201

    else :
        return "pas le bon token"



@app_transaction.route('/transaction/<user_id>', methods=['POST'])
def get_transaction(user_id):
    params = request.get_json()
    #user_id= params.get('user_id')
    token = params.get('token')
    email= User.get(User.id == user_id).email
    if check_token(email, token) is True:

        return jsonify({'transaction': list(Transaction
                 .select()
                 .where(Transaction.user == user_id).dicts()) }), 201

    else:
        return "pas le bon token"


@app_transaction.route('/transaction/<id>', methods=['PUT'])
def update_transaction(id):
   params = request.get_json()
   email= params.get('email')
   token = params.get('token')

   try:
       transaction = Transaction.get(Transaction.id == id)
       if check_token(email, token) is True:
            if params.get('label', None) is not None:
                   transaction.label = params.get('label')
            if params.get('amount', None) is not None:
                   transaction.amount = params.get('amount')
            if params.get('date', None) is not None:
                   transaction.date = params.get('date')
            if params.get('user_id', None) is not None:
                   transaction.user_id = params.get('user_id')
            transaction.save()
            data = model_to_dict(transaction)
            return jsonify({'transaction': data}), 201

       else :
            return "Authentification failed : bad token"

   except Exception as identifier:
       return jsonify({'error': 'Not found {message}'.format(message=identifier.message)}), 404


@app_transaction.route('/transaction/<id>', methods=['DELETE'])
def delete_transaction(id):
    params = request.get_json()
    email= params.get('email')
    token = params.get('token')
    try:
        if check_token(email, token) is True:
            transaction = Transaction.get(Transaction.id == id)
            transaction.delete_instance()
            return jsonify({'delete': 'ok'})
        else:
            return "Authentification failed : bad token"
    except Exception as identifier:
        return jsonify({'error': 'Not found'})



@app_transaction.route('/transaction/', methods=['GET'])
def get_all_transaction():

        return jsonify({'transaction': list(Transaction.select().dicts()) }), 201
