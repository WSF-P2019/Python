from flask import Blueprint, jsonify, request
from helpers.token_helper import token_helper
from models import Token
from models import User
from playhouse.shortcuts import model_to_dict, dict_to_model
import os, binascii
import hashlib

app_token = Blueprint('app_token', __name__)

#Creation d'un token
def create_token(user_id):

    key = binascii.b2a_hex(os.urandom(16))
    token = Token.create(ticket=key, user_id=user_id)
    token.save()
    return token.ticket



def check_token(email, token):
    try:
        user_found = User.get(User.email == email)
        token_found =  Token.get(Token.user_id == user_found.id)
        if token_found.ticket == token :
            return True
        else:
            return False
    except Exception:
            return False

@app_token.route('/token', methods=['GET'])
def get_all_token():
        return jsonify({'tokens': list(Token.select().dicts()) }), 201
