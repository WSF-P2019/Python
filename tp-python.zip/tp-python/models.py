from peewee import *
from playhouse.sqlite_ext import SqliteExtDatabase
import datetime
from datetime import timedelta

db = SqliteExtDatabase('my_database.db')

class BaseModel(Model):
    class Meta:
        database = db

class User(BaseModel):
    email = CharField()
    password = CharField()

class Token(BaseModel):
    ticket = CharField()
    user_id = CharField()

class Transaction(BaseModel):
    date = DateField()
    user = ForeignKeyField(User, related_name='user_transactions')
    amount = CharField()
    label = CharField()


# create table
User.create_table(True)
Token.create_table(True)
Transaction.create_table(True)

# connect db
db.connect()
